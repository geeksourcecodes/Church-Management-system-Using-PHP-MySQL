<?php include_once("init.php");
  ?>	<!-- HEADER -->
	<div id="header-with-tabs">
		
		<div class="page-full-width cf">
	
			<ul id="tabs" class="fl">
				<li><a href="dashboard.php" class="active-tab dashboard-tab">Dashboard</a></li>
				<li><a href="page-full-width.php" class="sales-tab">Sales</a></li>
				<li><a href="page-full-width.php" class="customers-tab">Customers</a></li>
				<li><a href="page-other.php" class="purchase-tab">Purchase</a></li>
				<li><a href="page-other.php" class="supplier-tab">Supplier</a></li>
				<li><a href="page-other.php" class="stock-tab">Stocks / Products</a></li>
				<li><a href="page-other.php" class="payment-tab">Payments / Outstandings</a></li>
				<li><a href="page-other.php" class="report-tab">Reports</a></li>
			</ul> <!-- end tabs -->
			
			<!-- Change this image to your own company's logo -->
			<!-- The logo will automatically be resized to 30px height. -->
                         
		</div> <!-- end full-width -->	

	</div> <!-- end header -->