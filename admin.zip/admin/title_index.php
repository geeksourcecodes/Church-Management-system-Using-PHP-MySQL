				
	<div class="row-fluid">
			<div class="span12"></div>
				  <div class="row-fluid">
						<div class="span10">
						<img class="index_logo" src="images/logo.png"  >
						</div>	
						<div class="span12">
							<div class="motto">
							<p></p>
							<p></p>												
							</div>											
						</div>							
				  </div>		   							
    </div>	
				