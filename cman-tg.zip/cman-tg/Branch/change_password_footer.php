<div style="text-align:center">
		<footer>
           <p>Southland College Technology Resource Inventory System</p>
        <footer>
</div>