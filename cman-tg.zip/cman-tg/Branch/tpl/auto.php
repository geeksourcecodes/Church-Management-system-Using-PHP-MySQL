<link rel="stylesheet" type="text/css" href="../auto/css/demos.css" />
<link rel="stylesheet" type="text/css" href="../auto/css/jquery.ui.base.css" />
<link rel="stylesheet" type="text/css" href="../auto/css/jquery.ui.theme.css" />
<script type="text/javascript" src="../auto/js/jquery-1.9.1.js"></script> 
<script type='text/javascript' src='../auto/js/jquery.ui.core.js'></script>
<script type='text/javascript' src='../auto/js/jquery.ui.widget.js'></script>
<script type='text/javascript' src='../auto/js/jquery.ui.menu.js'></script>
<script type='text/javascript' src='../auto/js/jquery.ui.autocomplete.js'></script>